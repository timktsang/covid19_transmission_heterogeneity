Demo Data and R syntax for the following paper:
Tim K. Tsang, Xiaotong Huang, Can Wang, Sijie Chen, Bingyi Yang, Simon Cauchemez, Benjamin J. Cowling

The effect of variation of individual infectiousness on SARS-CoV-2 transmission in households

+---------------------------------------------+
| System requirements and installation guide  |
+---------------------------------------------+

Please install R software, and install the used package, including 
1. Rcpp
2. RcppParallel
3. RcppArmadillo

Install time should be less than 10 mins
For windows user, Rtools 4.0 is required


+--------------------------------+
|  Demo and instruction for use  |
+--------------------------------+

File needed:

A. [data_demo.csv] This data file contains demo data


1. Household ID
2. hosuehold member i.d
3. Study id (for file contained more than 1 study)
4-5. the day for start and end of follow-up
6. the infection status for participant 1 (index)
7. infection time for participant 1
8. random effect for infectiousness of index cases (unobserved, will be sampled in the algorithm)
11: infection status for participant 2
12: infection time for participant 2 (-1 for uninfected contact)

for other household contact X, the infection status is in column 6+5*X, and infection tim is in column 7+5*X

B. [see.cpp] The file that are used by [sse.R].

C. [sse.R] The file for running the data-augmentation MCMC to obtain the main results in the paper


Run instruction:

1. Please install R and the required package. 
2. open the sse.R
3. Following the instruction in sse.R. 
4. Please remember set the link to the depository.
5. The expected run time is 1 hours for the whole dataset with estimation, and the DIC would require about 24 hours 

Expected output:
1. The posterior samples for all parameters, they are stored in tt[[1]]
2. The augmented relative infectiousness are stored in tt[[3]] 

Run the code for your data
If you have your own data, please clean the data in the format of data_demo.csv, then you can apply it.


# Demo Data and R syntax for the following paper:
# Tim K. Tsang, Xiaotong Huang, Can Wang, Sijie Chen, Bingyi Yang, Simon Cauchemez, Benjamin J. Cowling
# The effect of variation of individual infectiousness on SARS-CoV-2 transmission in households

rm(list = ls())

library(Rcpp)
library(RcppParallel)
library(matrixStats)

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
  y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
  y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
  for (i in 1:ncol(mcmc)){
  plot(mcmc[,i],type="l")
  }
  }
  return(y)
}

para_summary2 <- function(mcmc,a,b,print,filename){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  pdf(filename)
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  dev.off()
  return(y)
}

########
## incubation and infectiousness

incmat <- matrix(NA,1,14)
infmat <- matrix(NA,1,22)

incmat[1,] <- c(0.058,0.11,0.14,0.16,0.15,0.13,0.1,0.068,0.044,0.026,0.014,0.0072,0.0034,0.0015)
incmat[2,] <- c(0.04,0.065,0.082,0.093,0.098,0.098,0.095,0.088,0.080,0.071,0.061,0.052,0.043,0.035)
incmat <- incmat/rowSums(incmat)
infmat[1,] <- c(rep(1.0,8),0.8,0.6,0.4,0.2,0.1,rep(0,9))
infmat[2,] <- c(rep(1.0,12),0.8,0.8,0.6,0.6,0.4,0.4,0.3,0.3,0.1,0.1)

incvec <- incmat[1,]
infvec <- infmat[1,]

## input the study id for dataset included more than 1 study 
id <- 1

# based on this vec to generate the rel inf since infection
infvec2 <- rep(0,50)
for (i in 1:14){
  for (j in 1:22){
    if (i+j-5>0){
      infvec2[i+j-5] <- infvec2[i+j-5] + incvec[i]*infvec[j]
    }
  }
}
infvec2 <- infvec2/sum(infvec2)
infvec2 <- infvec2[infvec2>0]
################

## set the link for the file
try(setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/Shared COVID project/SAR/summary/inference_demo"))

# data is in the following format:
# col: 1: hhID, 2: household size, 3: study id, 4 and 5: study and end of following up
# 6: infection status for participant 1 (index cases), 7: infection time for participant 1
# 8: random effect for infectiousness of index cases (unobserved, will be sampled in the algorithm)
# 11: infection status for participant 2, 12: infection time for participant 2 (-1 for uninfected contact)
# for other household contact X, the infection status is in column 6+5*X, and infection tim is in column 7+5*X
data <- read.csv("data_demo.csv",as.is = T)

# parameter in the model
# para 1. random effect s.d on infectiousness
# para 2. from community
# para 3. from household
# para 4. the parameter to characterize the relationship between number of household contacts and transmission

para <-  c(1,0.001,0.1,0.01,0.1)
sourceCpp("sse.cpp")

# input the initial s.d. for the metropolis hasting
sigma <- c(1,rep(0.1,4))
# specific if the parameter is sampled
move <- rep(0,5)
move[c(1,2,3,4)] <- 1 

data1 <- as.matrix(data)
aaaaa1 <- Sys.time()
tt <- mcmc(data1,infvec2,100000,para,move,sigma)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

#write.csv(tt[[1]],"mcmc_result.csv")

inc <- 50000+1:10000*5
z1 <- para_summary((tt[[1]][inc,]),4,4,1)
id2 <- runif(1,0,1)
para_summary2((tt[[1]][inc,]),4,4,1,paste("mcmc_summary1.pdf",sep=""))
write.csv(z1,paste("mcmc_summary1.csv",sep=""))


##########################################################################################
## for compute model adequency
## this will generate a file that can be coverted to the model adequency check in appendix
## create a function to generate a model adequency check
count <- function(temp){
  out <- matrix(NA,1,14*14)
  infn <- rowSums(temp[,2:10*5+1]==1)
  
  for (i in 0:13){
    for (j in 0:13){
      out[1,14*i+j+1] <- sum(temp[,2]==i & infn==j)  
    }  
  }
  
  out
}

# the first row is the data
adeq <- matrix(NA,10000,196)
real <- count(data1)

sourceCpp("sse.cpp")


a1 <- tt[[1]][inc,]
a2 <- tt[[3]][1:10000,]

for (i in 1:10000){
  if (i%%100==0){print(i)}
  uu <- cond_sim_data(data1,infvec2,a2[i,],a1[i,],5,5)
  adeq[i,] <- count(uu[[1]])
}

z3 <- para_summary(adeq,4,3,0)
z3[,4] <- real

write.csv(z3,paste("adeq1.csv",sep=""))

##########################################################################################
### compute DIC here
a1 <- tt[[1]][inc,]
a2 <- tt[[3]][1:10000,]

a1 <- rbind(colMeans(a1),a1)
a2 <- rbind(colMeans(a2),a2)

sourceCpp("sse.cpp")

  uu <- DIC(data1,a1,a2,infvec2,2000,5,5)
  DIC_value <- -2*(2*mean(uu[2:nrow(a1)]) - uu[1])
  print(DIC_value)
  print(i)
  write.csv(DIC_value,paste("DIC_value1.csv",sep=""))


